<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class order_tbl extends Model
{
    protected $table='order_tbl';
}
