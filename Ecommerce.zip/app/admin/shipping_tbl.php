<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class shipping_tbl extends Model
{
    
    protected $table='shipping_tbl';
	public $timestamps = false;
}
