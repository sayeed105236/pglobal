<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class payment_detail_tbl extends Model
{
    protected $table='payment_detail_tbl';
    public $timestamps = false;
}
