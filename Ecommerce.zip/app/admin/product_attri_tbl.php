<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class product_attri_tbl extends Model
{
    
    protected $table='product_attri_tbl';
}
