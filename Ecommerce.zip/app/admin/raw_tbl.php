<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class raw_tbl extends Model
{
    protected $table='raw_tbl';
}
