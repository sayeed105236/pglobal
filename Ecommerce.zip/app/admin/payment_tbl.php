<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class payment_tbl extends Model
{
    protected $table='payment_tbl';
}
