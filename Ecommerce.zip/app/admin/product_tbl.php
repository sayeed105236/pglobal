<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class product_tbl extends Model
{
    
    protected $table='product_tbl';
}
