<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class order_detail_tbl extends Model
{
    protected $table='order_detail_tbl';
	public $timestamps = false;
}
