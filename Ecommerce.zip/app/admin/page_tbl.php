<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class page_tbl extends Model
{
    protected $table='page_tbl';
}
