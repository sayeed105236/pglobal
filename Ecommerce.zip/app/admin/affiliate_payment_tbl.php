<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class affiliate_payment_tbl extends Model
{
    
    protected $table='affiliate_payment_tbl';
}
