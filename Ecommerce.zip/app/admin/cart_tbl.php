<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class cart_tbl extends Model
{
	public $timestamps = false;
    protected $table='cart_tbl';
}
