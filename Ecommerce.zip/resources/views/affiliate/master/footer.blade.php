
    <script src="{{asset('resources/backend/assets/libs/jquery/dist/jquery.min.js')}}"></script>
    <script src="{{asset('resources/backend/assets/libs/bootstrap/dist/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('resources/backend/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')}}"></script>
    <script src="https://kit.fontawesome.com/7e9cbdcf79.js" crossorigin="anonymous"></script>
    <script src="{{asset('resources/backend/dist/js/sidebarmenu.js')}}"></script>
    <script src="{{asset('resources/backend/dist/js/custom.min.js')}}"></script>